<?php

	// ----- newsletter processing ----- //
	
	
	// --------------------------------- //	
	header('Location: form_success.htm');  

?>
